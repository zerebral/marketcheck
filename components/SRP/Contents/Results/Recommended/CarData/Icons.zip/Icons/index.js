import Air from './air.svg'
import Bluetooth from './bluetooth.svg'
import Brake from './brake.svg'
import Cam from './cam.svg'
import Certified from './certified.svg'
import Geo from './geo.svg'
import Keyless from './keyless.svg'
import Like from './like.svg'
import Share from './share.svg'
import Soon from './soon.svg'
import Wheels from './wheels.svg'

export {
  Air,
  Bluetooth,
  Brake,
  Cam,
  Certified,
  Geo,
  Keyless,
  Like,
  Share,
  Soon,
  Wheels
}
